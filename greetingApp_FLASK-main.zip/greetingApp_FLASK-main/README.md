# greetingApp_FLASK
a simple greeting app built with flask, ready to deploy to Heroku

![ss](https://user-images.githubusercontent.com/32107652/134775021-659d1384-0c37-43a7-b373-593d87f2b475.png)
<br>
<br>
Author: Mariya Sha
<br>
Watch on YouTube: https://youtu.be/6plVs_ytIH8
